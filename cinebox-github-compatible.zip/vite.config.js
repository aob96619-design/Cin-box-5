import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// VITE_BASE_PATH lets GitHub Actions build for /<repository>/ on GitHub Pages.
export default defineConfig({
  base: process.env.VITE_BASE_PATH || "/",
  plugins: [react()],
  server: {
    port: 5173,
    proxy: { "/api": "http://localhost:3001", "/media": "http://localhost:3001" }
  }
});

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
export const dataDir = path.join(here, "data");
export const uploadDir = path.join(here, "uploads");
const dbPath = path.join(dataDir, "db.json");

const demoTitles = [
  { id: "night-signal", title: "Night Signal", type: "Film", year: 2025, genre: "Science-fiction", rating: "8.4", duration: "2 h 08", poster: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1800&q=90", description: "Un signal venu des confins de l'espace semble répondre aux pensées humaines.", videoUrl: "", featured: true },
  { id: "blue-hour", title: "Blue Hour", type: "Film", year: 2024, genre: "Drame", rating: "7.9", duration: "1 h 54", poster: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1800&q=90", description: "Une photographe retourne dans son village côtier et retrouve son passé.", videoUrl: "", featured: false },
  { id: "wild-earth", title: "Wild Earth", type: "Série", year: 2025, genre: "Documentaire", rating: "9.1", duration: "2 saisons", poster: "https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=1800&q=90", description: "Une exploration des écosystèmes les plus étonnants de la planète.", videoUrl: "", featured: false },
  { id: "red-line", title: "Red Line", type: "Film", year: 2023, genre: "Thriller", rating: "8.0", duration: "1 h 47", poster: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1800&q=90", description: "Une journaliste reçoit des messages annonçant des événements avant qu'ils arrivent.", videoUrl: "", featured: false },
  { id: "paper-moons", title: "Paper Moons", type: "Série", year: 2024, genre: "Mystère", rating: "8.2", duration: "1 saison", poster: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1800&q=90", description: "Des disparitions anciennes refont surface après une éclipse.", videoUrl: "", featured: false },
  { id: "golden-mile", title: "Golden Mile", type: "Film", year: 2022, genre: "Aventure", rating: "7.6", duration: "2 h 01", poster: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1800&q=90", description: "Deux amis traversent un continent pour retrouver un carnet mystérieux.", videoUrl: "", featured: false },
  { id: "last-orbit", title: "Last Orbit", type: "Série", year: 2025, genre: "Science-fiction", rating: "8.7", duration: "1 saison", poster: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1800&q=90", description: "L'équipage d'une station isolée perd le contact avec la Terre.", videoUrl: "", featured: false },
  { id: "quiet-city", title: "Quiet City", type: "Film", year: 2024, genre: "Drame", rating: "7.8", duration: "1 h 39", poster: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=700&q=85", backdrop: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1800&q=90", description: "En une nuit, plusieurs destins se croisent dans une ville qui ne dort jamais.", videoUrl: "", featured: false }
];

export function ensureStore() {
  fs.mkdirSync(dataDir, { recursive: true });
  fs.mkdirSync(uploadDir, { recursive: true });
  if (!fs.existsSync(dbPath)) {
    writeDb({ users: [], titles: demoTitles, favorites: [], progress: [], submissions: [] });
  }
}

export function readDb() {
  ensureStore();
  return JSON.parse(fs.readFileSync(dbPath, "utf8"));
}

export function writeDb(db) {
  fs.mkdirSync(dataDir, { recursive: true });
  const tmp = `${dbPath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, dbPath);
}

export function makeId(prefix = "id") {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}
